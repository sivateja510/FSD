"use strict";
var rodone = document.getElementById("rod-one");
var rodtwo = document.getElementById("rod-two");
var ball = document.getElementById("ball");
var ctimeout = false;
var cscore =
{
    first: 0,
    second: 0,
}
var action =
{
    loosing_side: "",
    lost: false
}
function ce(element)
{
    element.style.left = ((document.documentElement.clientWidth / 2) - (element.offsetWidth / 2)).toString() + "px";
    element.style.left = ((document.documentElement.clientWidth / 2) - (element.offsetWidth / 2)).toString() + "px";
    if (element == ball)
    {
        if (action.lost)
        {
            if (action.loosing_side == "first")
            {
                ball.style.top = (rodone.clientHeight+5).toString() + "px";
            }
            else
            {
                ball.style.top = (document.documentElement.clientHeight - rodtwo.clientHeight - ball.clientHeight-5).toString() + "px";
            }
        }
        else
            element.style.top = (document.documentElement.clientHeight / 2).toString() + "px";
    }
}

function add_event_listener_to_rods()
{
    window.addEventListener("keydown", function (event)
    {
        let code = event.keyCode;
        if (code == 68)
        {

            let lnc = parseInt(
                rodone.style.left.substring(0, rodone.style.left.length - 2)
            );
            lnc += 20;
            if (lnc + rodone.offsetWidth > document.documentElement.clientWidth)
            {
                lnc = document.documentElement.clientWidth - rodone.offsetWidth;
            }
            rodone.style.left = lnc.toString() + "px";
            rodtwo.style.left = lnc.toString() + "px";
        } else if (code == 65)
        {
            let lnc = parseInt(
                rodone.style.left.substring(0, rodone.style.left.length - 2)
            );
            lnc -= 20;
            if (lnc < 0)
            {
                lnc = 0;
            }
            rodone.style.left = lnc.toString() + "px";
            rodtwo.style.left = lnc.toString() + "px";
        }
    });
}
function touched_upper_bar()
{
    let btnl = ball.getBoundingClientRect().top;
    let blnl = ball.getBoundingClientRect().left;
    let bln = parseInt(rodone.style.left.substring(0, rodone.style.left.length - 2));
    if ((btnl <= rodone.clientHeight) && (blnl + (ball.clientWidth / 2) > bln) && (blnl + (ball.clientWidth / 2) < bln + rodone.clientWidth))
    {
        if (!ctimeout)
        {
            ctimeout = true;
            setTimeout(function ()
            {
                cscore.first++;
                ctimeout = false;
                console.log("first", cscore.first);
            }, 200);
        }
        return true;
    }
    return false;
}
function touched_lower_bar()
{
    let btnl = ball.getBoundingClientRect().top;
    let blnl = ball.getBoundingClientRect().left;
    let bln = parseInt(rodtwo.style.left.substring(0, rodtwo.style.left.length - 2));
    if ((btnl + ball.clientHeight + rodtwo.clientHeight >= document.documentElement.clientHeight) && (blnl + (ball.clientWidth / 2) > bln) && (blnl + (ball.clientWidth / 2) < bln + rodtwo.clientWidth))
    {
        if (!ctimeout)
        {
            ctimeout = true;
            setTimeout(function ()
            {
                cscore.second++;
                ctimeout = false;
                console.log("second", cscore.second);
            }, 200);
        }
        return true;
    }
    return false;
}
function set_interval_for_ball()
{

    let interval_id = setInterval(function ()
    {
        let nl = ball.getBoundingClientRect().left;
        let nt = ball.getBoundingClientRect().top;
        if (nl <= 0)//hit left
        {
            let cp = ball.classList[0];
            if (cp == "atl")
            {
                ball.classList.remove(cp);
                ball.classList.add("atr");
            }
            else if (cp == "abl")
            {
                ball.classList.remove(cp);
                ball.classList.add("abr");
            }
        }
        else if (nl + ball.offsetWidth >= document.documentElement.clientWidth)//hit right
        {
            let cp = ball.classList[0];
            if (cp == "atr")
            {
                ball.classList.remove(cp);
                ball.classList.add("atl");
            }
            else if (cp == "abr")
            {
                ball.classList.remove(cp);
                ball.classList.add("abl");
            }
        }
        else if (nt <= 0 || nt + ball.offsetHeight >= document.documentElement.clientHeight)//game over
        {
            ball.classList.remove(ball.classList[0])
            if (nt <= 0)
            {
                action.loosing_side = "first";
                action.lost = true;
            }
            else if (nt + ball.offsetHeight >= document.documentElement.clientHeight)
            {
                action.loosing_side = "second";
                action.lost = true;
            }
            ce(ball);
            ce(rodone);
            ce(rodtwo);

            alert('Game Over');
            clearInterval(interval_id);
            if (cscore.first > localStorage.getItem('first'))
            {
                localStorage.setItem('first', cscore.first);
            }
            if (cscore.second > localStorage.getItem('second'))
            {
                localStorage.setItem('second', cscore.second);
            }
            cscore.first=0;
            cscore.second=0;
            ss();
        }
        else if (touched_lower_bar())//touched lower bar
        {
            let cp = ball.classList[0];
            if (cp == "abr")
            {
                ball.classList.remove(cp);
                ball.classList.add("atr");
            }
            else if (cp == "abl")
            {
                ball.classList.remove(cp);
                ball.classList.add("atl");
            }
        }
        else if (touched_upper_bar())//touched upper bar
        {
            let cp = ball.classList[0];
            if (cp == "atr")
            {
                ball.classList.remove(cp);
                ball.classList.add("abr");
            }
            else if (cp == "atl")
            {
                ball.classList.remove(cp);
                ball.classList.add("abl");
            }
        }
    }, 1)
}
function ss()
{
    if (localStorage.getItem('first') == null)
    {
        localStorage.setItem('first', 0);
        localStorage.setItem('second', 0);
        window.alert("This is your first time");
    }
    else
    {
        window.alert("Rod 1 has a maximum score of " + localStorage.getItem('first').toString() + "\n" + "Rod 2 has a maximum score of " + localStorage.getItem('second'));
    }
}

ce(rodone);
ce(rodtwo);
ce(ball);
ss();
add_event_listener_to_rods();
set_interval_for_ball();

document.addEventListener('keydown', function (event)
{
    if (event.keyCode == 13)
    {
        if (action.lost)
        {
            if (action.loosing_side == "first")
            {
                ball.classList.add('abr');
            }
            else
            {
                ball.classList.add('atr');
            }
        }
        else
            ball.classList.add('abr');
        set_interval_for_ball()
    }
})


